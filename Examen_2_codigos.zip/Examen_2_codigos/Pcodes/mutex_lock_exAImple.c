#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#define NUM_THREADS 5

pthread_mutex_t mutex; // Declare a mutex variable

// Function to be executed by each thread
void *thread_function(void *thread_id) {
    long tid;
    tid = (long)thread_id;
    
    // Lock the mutex before accessing shared resource
    pthread_mutex_lock(&mutex);
    printf("Thread %ld is accessing the shared resource.\n", tid);
    
    // Simulating some work being done by the thread
    sleep(0); // Sleep for 100ms
    
    // Release the mutex after accessing shared resource
    pthread_mutex_unlock(&mutex);
    printf("Thread %ld has finished.\n", tid);

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    int rc;
    long t;

    // Initialize the mutex
    pthread_mutex_init(&mutex, NULL);

    // Create threads
    for(t = 0; t < NUM_THREADS; t++) {
        printf("Creating thread %ld\n", t);
        rc = pthread_create(&threads[t], NULL, thread_function, (void *)t);
        if (rc) {
            printf("Error: unable to create thread, %d\n", rc);
            exit(-1);
        }
    }

    // Join threads
    for(t = 0; t < NUM_THREADS; t++) {
        pthread_join(threads[t], NULL);
    }

    // Destroy the mutex
    pthread_mutex_destroy(&mutex);

    return 0;
}

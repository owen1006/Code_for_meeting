#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

// Defining a structure for student
struct student {
    int id;
    int M; // Not used in this code, but left for future use
};

// Global variable for book lock
pthread_mutex_t book_lock;

void* runner(void* arg) {
    // Casting the argument back to the correct struct type
    struct student* s = (struct student*) arg;
    
    // Calculating the number of books for the student
    int books = s->id / 2; // Changed 's/2' to 's->id / 2'
    
    // Locking the book
    pthread_mutex_lock(&book_lock);
    
    // Printing the action of reading a book
    printf("Student %d is reading a book.\n", s->id);
    
    // Unlocking the book
    pthread_mutex_unlock(&book_lock);
    
    // Exiting the thread
    pthread_exit(NULL);
}

int main() {
    // Creating an array to hold pthread IDs
    pthread_t threads[5];
    
    // Initializing the book lock
    pthread_mutex_init(&book_lock, NULL);
    
    // Creating 5 student threads
    for (int i = 0; i < 5; i++) {
        struct student* s = (struct student*)malloc(sizeof(struct student));
        s->id = i + 1; // Assigning unique IDs to students
        pthread_create(&threads[i], NULL, runner, (void*)s);
    }
    
    // Waiting for all threads to finish
    for (int i = 0; i < 5; i++) {
        pthread_join(threads[i], NULL);
    }
    
    // Destroying the book lock
    pthread_mutex_destroy(&book_lock);
    
    return 0;
}

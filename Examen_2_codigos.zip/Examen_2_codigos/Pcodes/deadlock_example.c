#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex2 = PTHREAD_MUTEX_INITIALIZER;

void* thread1(void* arg) {
    // Lock mutex1
    pthread_mutex_lock(&mutex1);
    printf("Thread 1 locked mutex1\n");

    // Simulate some work
    sleep(1);

    // Attempt to lock mutex2
    printf("Thread 1 tries to lock mutex2\n");
    pthread_mutex_lock(&mutex2);
    printf("Thread 1 locked mutex2\n");

    // Do something with mutex1 and mutex2
    // (Critical section)

    // Unlock mutex2
    pthread_mutex_unlock(&mutex2);
    printf("Thread 1 unlocked mutex2\n");

    // Unlock mutex1
    pthread_mutex_unlock(&mutex1);
    printf("Thread 1 unlocked mutex1\n");

    return NULL;
}

void* thread2(void* arg) {
    // Lock mutex2
    pthread_mutex_lock(&mutex2);
    printf("Thread 2 locked mutex2\n");

    // Simulate some work
    sleep(1);

    // Attempt to lock mutex1
    printf("Thread 2 tries to lock mutex1\n");
    pthread_mutex_lock(&mutex1);
    printf("Thread 2 locked mutex1\n");

    // Do something with mutex1 and mutex2
    // (Critical section)

    // Unlock mutex1
    pthread_mutex_unlock(&mutex1);
    printf("Thread 2 unlocked mutex1\n");

    // Unlock mutex2
    pthread_mutex_unlock(&mutex2);
    printf("Thread 2 unlocked mutex2\n");

    return NULL;
}

int main() {
    pthread_t tid1, tid2;

    // Create thread 1
    if (pthread_create(&tid1, NULL, thread1, NULL) != 0) {
        perror("pthread_create");
        exit(EXIT_FAILURE);
    }

    // Create thread 2
    if (pthread_create(&tid2, NULL, thread2, NULL) != 0) {
        perror("pthread_create");
        exit(EXIT_FAILURE);
    }

    // Wait for thread 1 to finish
    if (pthread_join(tid1, NULL) != 0) {
        perror("pthread_join");
        exit(EXIT_FAILURE);
    }

    // Wait for thread 2 to finish
    if (pthread_join(tid2, NULL) != 0) {
        perror("pthread_join");
        exit(EXIT_FAILURE);
    }

    return 0;
}

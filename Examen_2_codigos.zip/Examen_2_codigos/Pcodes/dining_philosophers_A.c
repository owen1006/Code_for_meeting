#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define NUM_PHILOSOPHERS 5

sem_t chopstick[NUM_PHILOSOPHERS];

void *philosopher(void *arg) {
    int id = *(int *)arg;
    int left = id;
    int right = (id + 1) % NUM_PHILOSOPHERS;

    // while (1) creates an infinite loop. The condition 1 is always true, so the loop
    // will continue indefinitely until explictly terminated.
    while (1) {
        // Thinking
        printf("Philosopher %d is thinking.\n", id);

        // Get left chopstick
        sem_wait(&chopstick[left]);
        printf("Philosopher %d got left chopstick.\n", id);

        // Get right chopstick
        sem_wait(&chopstick[right]);
        printf("Philosopher %d got right chopstick. Eating...\n", id);

        // Eating
        sleep(1);

        // Put down chopsticks
        sem_post(&chopstick[left]);
        printf("Philosopher %d put down left chopstick.\n", id);
        sem_post(&chopstick[right]);
        printf("Philosopher %d put down right chopstick.\n", id);
    }
    return NULL;
}

int main() {
    pthread_t philosophers[NUM_PHILOSOPHERS];
    int ids[NUM_PHILOSOPHERS];

    // Initialize semaphores
    for (int i = 0; i < NUM_PHILOSOPHERS; ++i) {
        sem_init(&chopstick[i], 0, 1);
    }

    // Create philosopher threads
    for (int i = 0; i < NUM_PHILOSOPHERS; ++i) {
        ids[i] = i;
        pthread_create(&philosophers[i], NULL, philosopher, &ids[i]);
    }

    // Join threads
    for (int i = 0; i < NUM_PHILOSOPHERS; ++i) {
        pthread_join(philosophers[i], NULL);
    }

    // Destroy semaphores
    for (int i = 0; i < NUM_PHILOSOPHERS; ++i) {
        sem_destroy(&chopstick[i]);
    }

    return 0;
}

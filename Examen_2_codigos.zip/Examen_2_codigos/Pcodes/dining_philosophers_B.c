#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define NUM_PHILOSOPHERS 5

sem_t chopstick[NUM_PHILOSOPHERS];

void *philosopher(void *arg) {
    int id = *(int *)arg;
    int left_chopstick = id;
    int right_chopstick = (id + 1) % NUM_PHILOSOPHERS;

    while (1) {
        // Thinking
        printf("Philosopher %d is thinking.\n", id);

        // Pick up chopsticks
        sem_wait(&chopstick[left_chopstick]);
        sem_wait(&chopstick[right_chopstick]);

        // Eating
        printf("Philosopher %d is eating.\n", id);
        sleep(1); // Simulating eating

        // Put down chopsticks
        sem_post(&chopstick[left_chopstick]);
        sem_post(&chopstick[right_chopstick]);
    }
    return NULL;
}

int main() {
    pthread_t philosophers[NUM_PHILOSOPHERS];
    int ids[NUM_PHILOSOPHERS];

    // Initialize semaphores
    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
        sem_init(&chopstick[i], 0, 1);

    // Create philosopher threads
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        ids[i] = i;
        pthread_create(&philosophers[i], NULL, philosopher, &ids[i]);
    }

    // Join philosopher threads
    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
        pthread_join(philosophers[i], NULL);

    // Destroy semaphores
    for (int i = 0; i < NUM_PHILOSOPHERS; i++)
        sem_destroy(&chopstick[i]);

    return 0;
}

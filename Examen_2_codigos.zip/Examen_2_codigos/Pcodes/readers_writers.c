#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>

#define MAX_READERS 5
#define MAX_WRITERS 5

pthread_t readers[MAX_READERS], writers[MAX_WRITERS];
sem_t mutex, rw_mutex;
int read_count = 0;

void *reader(void *arg) {
    while (1) {
        sem_wait(&mutex);
        read_count++;
        if (read_count == 1)
            sem_wait(&rw_mutex);
        sem_post(&mutex);

        // Reading is performed
        printf("Reader %ld is reading\n", pthread_self());

        sem_wait(&mutex);
        read_count--;
        if (read_count == 0)
            sem_post(&rw_mutex);
        sem_post(&mutex);
    }
}

void *writer(void *arg) {
    while (1) {
        sem_wait(&rw_mutex);

        // Writing is performed
        printf("Writer %ld is writing\n", pthread_self());

        sem_post(&rw_mutex);
    }
}

int main() {
    int i;
    sem_init(&mutex, 0, 1);
    sem_init(&rw_mutex, 0, 1);

    // Creating reader threads
    for (i = 0; i < MAX_READERS; i++)
        pthread_create(&readers[i], NULL, reader, NULL);

    // Creating writer threads
    for (i = 0; i < MAX_WRITERS; i++)
        pthread_create(&writers[i], NULL, writer, NULL);

    // Joining threads
    for (i = 0; i < MAX_READERS; i++)
        pthread_join(readers[i], NULL);

    for (i = 0; i < MAX_WRITERS; i++)
        pthread_join(writers[i], NULL);

    sem_destroy(&mutex);
    sem_destroy(&rw_mutex);

    return 0;
}

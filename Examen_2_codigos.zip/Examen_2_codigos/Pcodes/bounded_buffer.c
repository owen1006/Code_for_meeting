#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUFFER_SIZE 5
#define PRODUCER_THREADS 2
#define CONSUMER_THREADS 2

int buffer[BUFFER_SIZE];
sem_t mutex, empty, full;

void *producer(void *arg) {
    int item;
    while (1) {
        item = rand() % 100; // generate random item
        sem_wait(&empty);
        sem_wait(&mutex);
        /* add produced item to the buffer */
        printf("Producer %ld produced item: %d\n", (long)arg, item);
        // Critical section
        // Adding item to buffer
        for (int i = 0; i < BUFFER_SIZE; i++) {
            if (buffer[i] == 0) {
                buffer[i] = item;
                break;
            }
        }
        sem_post(&mutex);
        sem_post(&full);
        sleep(rand() % 3); // Simulate some work
    }
}

void *consumer(void *arg) {
    int item;
    while (1) {
        sem_wait(&full);
        sem_wait(&mutex);
        /* remove item from the buffer */
        // Critical section
        // Removing item from buffer
        for (int i = 0; i < BUFFER_SIZE; i++) {
            if (buffer[i] != 0) {
                item = buffer[i];
                buffer[i] = 0;
                break;
            }
        }
        printf("Consumer %ld consumed item: %d\n", (long)arg, item);
        sem_post(&mutex);
        sem_post(&empty);
        sleep(rand() % 3); // Simulate some work
    }
}

int main() {
    pthread_t prod_threads[PRODUCER_THREADS];
    pthread_t cons_threads[CONSUMER_THREADS];
    long i;

    sem_init(&mutex, 0, 1);
    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);

    for (i = 0; i < PRODUCER_THREADS; i++) {
        pthread_create(&prod_threads[i], NULL, producer, (void *)i);
    }

    for (i = 0; i < CONSUMER_THREADS; i++) {
        pthread_create(&cons_threads[i], NULL, consumer, (void *)i);
    }

    for (i = 0; i < PRODUCER_THREADS; i++) {
        pthread_join(prod_threads[i], NULL);
    }

    for (i = 0; i < CONSUMER_THREADS; i++) {
        pthread_join(cons_threads[i], NULL);
    }

    sem_destroy(&mutex);
    sem_destroy(&empty);
    sem_destroy(&full);

    return 0;
}

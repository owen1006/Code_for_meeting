#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h> // For O_CREAT, O_EXCL
#define BUFFER_SIZE 20

// Global Variables
int count = 0;
int buffer[BUFFER_SIZE];
sem_t *mutex;
sem_t *buffer_not_full;
sem_t *buffer_not_empty;

int in = 0; // Index for producer
int out = 0; // Index for consumer

void insert(int item) {
sem_wait(buffer_not_full);
sem_wait(mutex);

buffer[in] = item;
in = (in + 1) % BUFFER_SIZE;
count++;
printf("in: %d inserted: %d\n", in, item);

sem_post(mutex);
sem_post(buffer_not_empty);
}

int remove_item() {
int item;
sem_wait(buffer_not_empty);
sem_wait(mutex);

item = buffer[out];
out = (out + 1) % BUFFER_SIZE;
count--;
printf("out: %d removed: %d\n", out, item);

sem_post(mutex);
sem_post(buffer_not_full);

return item;
}

void *producer(void *param) {
int item;
while (1) {
item = rand() % BUFFER_SIZE;
insert(item);
sleep(1);
}
}

void *consumer(void *param) {
int item;
while (1) {
item = remove_item();
sleep(1);
}
}

int main(int argc, char *argv[]) {
if (argc != 3) {
printf("Usage: %s <producers> <consumers>\n", argv[0]);
return 1;
}

int producers = atoi(argv[1]);
int consumers = atoi(argv[2]);

mutex = sem_open("/mutex", O_CREAT | O_EXCL, 0644, 1);
buffer_not_full = sem_open("/buffer_not_full", O_CREAT | O_EXCL, 0644, BUFFER_SIZE);
buffer_not_empty = sem_open("/buffer_not_empty", O_CREAT | O_EXCL, 0644, 0);

pthread_t tid;

int i;
for (i = 0; i < producers; i++)
pthread_create(&tid, NULL, producer, NULL);
for (i = 0; i < consumers; i++)
pthread_create(&tid, NULL, consumer, NULL);

pthread_join(tid, NULL);

sem_close(mutex);
sem_close(buffer_not_full);
sem_close(buffer_not_empty);

sem_unlink("/mutex");
sem_unlink("/buffer_not_full");
sem_unlink("/buffer_not_empty");

return 0;
}

//owencolon@Owens-Air-3 ~ % cd Documents
//owencolon@Owens-Air-3 Documents % cd "Universidad de Mayaguez"
//owencolon@Owens-Air-3 Universidad de Mayaguez % cd CIIC4050
//owencolon@Owens-Air-3 CIIC4050 % cd Examen_2_codigos
//owencolon@Owens-Air-3 Examen_2_codigos % cd Pcodes
//owencolon@Owens-Air-3 Pcodes % gcc -o Lab_Ex_4 Lab_Ex_4.c -lpthread
//owencolon@Owens-Air-3 Pcodes % ./Lab_Ex_4 2 1
//in: 1 inserted: 7
//in: 2 inserted: 9
//out: 1 removed: 7
//in: 3 inserted: 13
//out: 2 removed: 9
//in: 4 inserted: 18
//in: 5 inserted: 10
//in: 6 inserted: 12
//out: 3 removed: 13
//in: 7 inserted: 4
//in: 8 inserted: 18
//out: 4 removed: 18
//in: 9 inserted: 3
//in: 10 inserted: 9
//out: 5 removed: 10
//in: 11 inserted: 0
//in: 12 inserted: 5
//out: 6 removed: 12
//in: 13 inserted: 12
//in: 14 inserted: 2
//out: 7 removed: 4
//in: 15 inserted: 7


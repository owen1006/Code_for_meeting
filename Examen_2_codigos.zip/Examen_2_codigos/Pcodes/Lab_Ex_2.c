#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

// Global Variables
int threads;
unsigned long long iterations;
double *pi;

// Declares the prototype of the function 'runner', which each thread will execute
void *runner(void *param);

int main(int argc, char *argv[]) {
// Argument Check
if (argc != 3) {
fprintf(stderr, "usage: %s <iterations> <threads>\n", argv[0]);
return -1;
}

// Argument Parsing Convert the command-line arguments to appropriate data types 
//(unsigned long long for iterations, and int for threads).
iterations = atoll(argv[1]);
threads = atoi(argv[2]);

// Input Validation that ensures that both iterations and threads are non-negative 
if (iterations < 0 || threads < 0) {
fprintf(stderr, "Arguments must be non-negative\n");
return -1;
}

// Memory Allocation: Allocate memory for the array pi to store partial results.
pi = (double *)malloc(threads * sizeof(double));
if (pi == NULL) {
fprintf(stderr, "Memory allocation failed\n");
return -1;
}

// Thread Creation: Create an array to hold thread IDs and allocate memory for it.
pthread_t *thread_ids = (pthread_t *)malloc(threads * sizeof(pthread_t));
if (thread_ids == NULL) {
fprintf(stderr, "Memory allocation failed\n");
free(pi);
return -1;
}

// Thread Execution: Create threads, each executing the runner function.
for (int i = 0; i < threads; i++) {
pthread_attr_t attr;
pthread_attr_init(&attr);
pthread_create(&thread_ids[i], &attr, runner, (void *)(intptr_t)i);
}

// Thread Joining: Wait for all threads to finish execution.
for (int i = 0; i < threads; i++) {
pthread_join(thread_ids[i], NULL);
}

// Compute Pi Approximation: Sum up the partial results computed by each thread.
double result = 0.0;
for (int i = 0; i < threads; i++) {
result += pi[i];
}
result *= 4;

// Output
printf("pi = %.15f\n", result);

// Memory Cleanup: Free dynamically allocated memory.
free(pi);
free(thread_ids);
return 0;
}

// Thread Function: The function that each thread executes. 
// It calculates the partial sum for a specific range of iterations.
void *runner(void *param) {
int thread_id = (intptr_t)param;
double sign = (thread_id % 2 == 0) ? 1.0 : -1.0;
unsigned long long start = thread_id * (iterations / threads);
unsigned long long end = (thread_id == threads - 1) ? iterations : (thread_id + 1) * (iterations / threads);

pi[thread_id] = 0.0;

for (unsigned long long i = start; i < end; i++) {
double term = sign / (2 * i + 1);
pi[thread_id] += term;
sign = -sign;
}

pthread_exit(0);
}

// To be able to run the program:  
//Last login: Sat Mar 16 22:39:35 on ttys000
//owencolon@Owens-Air-3 ~ % cd Documents
//owencolon@Owens-Air-3 Documents % cd "Universidad de Mayaguez"
//owencolon@Owens-Air-3 Universidad de Mayaguez % cd CIIC4050
//owencolon@Owens-Air-3 CIIC4050 % ls
//owencolon@Owens-Air-3 CIIC4050 % cd Examen_2_codigos
//owencolon@Owens-Air-3 Examen_2_codigos % cd Pcodes
//owencolon@Owens-Air-3 Pcodes % gcc -o Lab_Ex_2 Lab_Ex_2.c -lpthread
//owencolon@Owens-Air-3 Pcodes % ./Lab_Ex_2 10000 4
//pi = 3.141025986952062

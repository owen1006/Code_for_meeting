#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
// Macro Definition
#define BUFFER_SIZE 20

// Global Variables
int count = 0; // Items in the buffer
int buffer [BUFFER_SIZE]; // Array to hold items
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER; // Mutex lock for protecting critical sections.
pthread_cond_t buffer_not_full = PTHREAD_COND_INITIALIZER; // Condition for buffer not full
pthread_cond_t buffer_not_empty = PTHREAD_COND_INITIALIZER; // Condition for buffer not empty
pthread_t tid; // Thread ID

int in = 0; // Index for producer
int out = 0; // Index for consumer

void insert(int item){
pthread_mutex_lock(&mutex);
while (count == BUFFER_SIZE) {
pthread_cond_wait(&buffer_not_full, &mutex);
}
buffer[in] = item;
in = (in + 1) % BUFFER_SIZE; // Update index in a circular manner
count++;
printf("in: %d inserted: %d\n", in, item);
pthread_cond_signal(&buffer_not_empty);
pthread_mutex_unlock(&mutex);
}

int remove_item(){
int item;
pthread_mutex_lock(&mutex);
while (count == 0) {
pthread_cond_wait(&buffer_not_empty, &mutex);
}
item = buffer[out];
out = (out + 1) % BUFFER_SIZE; // Update index in a circular manner
count--;
printf("out: %d removed: %d\n", out, item);
pthread_cond_signal(&buffer_not_full);
pthread_mutex_unlock(&mutex);
return item;
}

void * producer(void * param){
int item;
while(1){
item = rand() % BUFFER_SIZE ;
insert(item);
sleep(1);
}
}

void * consumer(void * param){
int item;
while(1){
item = remove_item();
sleep(1);
}
}

int main(int argc, char * argv[]) {
if (argc != 3) {
printf("Usage: %s <producers> <consumers>\n", argv[0]);
return 1;
}

int producers = atoi(argv[1]);
int consumers = atoi(argv[2]);

pthread_t tid;

int i;
for (i = 0; i < producers; i++)
pthread_create(&tid, NULL, producer, NULL);
for (i = 0; i < consumers; i++)
pthread_create(&tid, NULL, consumer, NULL);

pthread_join(tid, NULL);

return 0;
}

// To be able to run the program:  
//Last login: Sat Mar 16 22:39:35 on ttys000
//owencolon@Owens-Air-3 ~ % cd Documents
//owencolon@Owens-Air-3 Documents % cd "Universidad de Mayaguez"
//owencolon@Owens-Air-3 Universidad de Mayaguez % cd CIIC4050
//owencolon@Owens-Air-3 CIIC4050 % ls
//owencolon@Owens-Air-3 CIIC4050 % cd Examen_2_codigos
//owencolon@Owens-Air-3 Examen_2_codigos % cd Pcodes
//owencolon@Owens-Air-3 Pcodes % gcc -o Lab_Ex_3 Lab_Ex_3.c -lpthread
//owencolon@Owens-Air-3 Pcodes % ./Lab_Ex_3 2 1
//in: 1 inserted: 9
//in: 2 inserted: 7
//out: 1 removed: 9
//in: 3 inserted: 13
//in: 4 inserted: 18
//out: 2 removed: 7
//in: 5 inserted: 10
//in: 6 inserted: 12
//out: 3 removed: 13
//in: 7 inserted: 4
//in: 8 inserted: 18
//out: 4 removed: 18
//in: 9 inserted: 3
//in: 10 inserted: 9
//out: 5 removed: 10
//in: 11 inserted: 0
//out: 6 removed: 12
//in: 12 inserted: 5
//out: 7 removed: 4
//in: 13 inserted: 12
//in: 14 inserted: 2
//out: 8 removed: 18